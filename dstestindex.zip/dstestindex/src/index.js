import OpenAI from "openai";


//This stufff is supposed to handle the interaction between the web page and deepseek.
const openai = new OpenAI({
        baseURL: 'https://api.deepseek.com',
        apiKey: 'sk-ebc47879fdd1444192597402b83583d5',
        //This is obviously a bad idea but I don't know any other way
        dangerouslyAllowBrowser: true
});

export async function dsrequest(userinput) {
  const completion = await openai.chat.completions.create({
    messages: [{ role: "system", content: userinput }],
    model: "deepseek-chat",
  });

  console.log(completion.choices[0].message.content);
  outputArea.textContent = (completion.choices[0].message.content);
  
}

  //Here is the code for index.html
  const rewriteBtn = document.getElementById("rewriteBtn"); 
  const resumeInput = document.getElementById("resumeInput");
  const fieldInput = document.getElementById("fieldInput");
  
  rewriteBtn.addEventListener("click", async () => {
    console.log(resumeInput.value)
    if (fieldInput.value === "") {
        let userResume = 'Please rewrite the following resume to make it more professional and concise: ' + resumeInput.value;
    }
    else {
        let userResume = 'Please rewrite the following resume for a ' + fieldInput.value + ' position to make it more professional and concise: ' + resumeInput.value;
    }
        dsrequest(userResume)
    outputArea.textContent = "Please wait while your resume is rewritten...";
   });