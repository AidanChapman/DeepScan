import OpenAI from "openai";


//This stufff is supposed to handle the interaction between the web page and deepseek.
const openai = new OpenAI({
        baseURL: 'https://api.deepseek.com',
        apiKey: 'sk-ebc47879fdd1444192597402b83583d5',
        //This is obviously a bad idea but I don't know any other way
        dangerouslyAllowBrowser: true
});

export async function dsrequest(userinput) {
  const completion = await openai.chat.completions.create({
    messages: [{ role: "system", content: userinput }],
    model: "deepseek-chat",
  });

  console.log(completion.choices[0].message.content);
  outputArea.textContent = (completion.choices[0].message.content);
  
}

//Here is the main code for the resume builder web page
 console.log("Testing log functionality"); 
const experienceinput = document.getElementById("experience-input");
const outputArea = document.getElementById("outputArea");
const uploadButton = document.getElementById("uploadexp");

  uploadButton.addEventListener("click", async () => {
                            
    console.log(experienceinput.value);
    let experience = 'Please create a resume based on the following experience: ' + experienceinput.value;
      dsrequest(experience);
    outputArea.textContent = "Please wait while we process your resume...";
  });